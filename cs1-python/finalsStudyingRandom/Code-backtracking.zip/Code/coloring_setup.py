"""
  Map coloring configuration file used by the map_coloring program

  Edit this to set up the global, runtime parameters for the program.

  coloring_setup.py
  author: James Heliotis
"""

import os

# Parameters for choosing an instance of the problem

UNCOLORED = -1

COLORS = ( "yellow", "magenta", "cyan" ) #, "lightGreen" ) #, "blue" )

NUM_COLORS = len( COLORS )

COUNTRY = os.path.join( "data", "US" ) # prefix for the data file names
#COUNTRY = os.path.join( "data", "NE" ) # prefix for the data file names
#COUNTRY = os.path.join( "data", "NEng" ) # prefix for the data file names

FILENAME_SUFFIX = "Graph.txt" # all graph description filenames end this way

# Execution settings

SHOW_PROGRESS = True
SLEEP = True                  # If showing progress, sleep vs step
SLEEP_TIME = 0.1

# Display settings

WIN_WIDTH = 700
MARGIN = 50

