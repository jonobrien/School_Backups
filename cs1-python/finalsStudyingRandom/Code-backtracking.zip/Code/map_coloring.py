#!/usr/local/bin/python3.1

"""
  Map coloring problem:

  Can a map be colored with only N colors so that no two neighboring states
  use the same color?

  This demonstrates a backtracking algorithm.
  Guess one part of the solution, then another, then another, until you have
  no legitimate choices left. This is like depth-first searching.
  Assuming you have not reached your goal yet, *back up* the most
  recent guesses until you get back to a spot where you had more choices
  you could have made, and guess differently.

  Consider a map of states to be a graph where nodes are states and
  edges between nodes represent a shared boundary between the corresponding
  states.

  The problem where N==4 and the graph is planar (like a map) is famous
  because a computer program was written to prove that such a graph is
  always 4-colorable.

  -> Notes on type specifications:
  The Graph type is defined in utilities module.
  The ListOfInt type associates integer color codes to map regions (states).

  Author: James Heliotis
  Author: ben k steele
  $Revision: 1.5 $

"""

########## IMPORTS ###########

# The utilities module contains an implementation of a graph that converts
# node (state) names to numbers so that comparisons go faster.
import utilities

# More utilities from the Python library
import copy
import time

# Class definitions for states and how to draw maps of states.
import state_map

# The graphics package used to draw the states (John Zelle, Wartburg U.)
import graphics

# The file that contains the execution parameter settings
# Any variables you see named with all UPPER CASE come from coloring_setup.
from coloring_setup import *

########## FUNCTIONS ###########

def buildGraph( country ):
    """
       buildGraph : String -> Graph
       Read which states border on which other states and
       return a graph of connected states.
    """
    adjFileName = country + FILENAME_SUFFIX

    # Each line in the file contains a state, followed by its neighbors.

    # Go through the file to pick up all the state names
    # and assign numbers to them.
    graph = utilities.Graph()

    with open( adjFileName ) as adjFile:
        for entry in adjFile:
            adjList = entry.rstrip().split( ',' )
            sourceName = adjList.pop( 0 )
            sourceIndex = utilities.add( graph, sourceName )
            source = graph.nodes[ sourceIndex ]
            for destName in adjList:
                destIndex = utilities.add( graph, destName )
                source.neighbors.append( destIndex )

    return graph

def nextColorings( stateColors, graph ):
    """
       nextColorings : ListOfInt Graph -> ListOfInt
       Find an as yet uncolored state.
       Using copies of the current stateColors configuration,
       set that uncolored state to all possible colors.
       Put those modified copies in a list and return it.

       As with the nodes' names, colors are just represented
       internally with numbers. This is done to run the
       algorithm faster.
    """
    candidate = None
    for stateNum in range( len( graph.nodes ) ):
        sourceColor = stateColors[ stateNum ]
        if sourceColor == UNCOLORED:
            candidate = stateNum
            break;

    # At this point an uncolored state may have been found.
    # Its index is in candidate.
    # Create a list of stateColors lists that has that node colored
    # with every possible color.

    colorings = []
    if candidate != None:
        for color in range( NUM_COLORS ):
            newStateColors = copy.copy( stateColors )
            newStateColors[ candidate ] = color
            colorings.append( newStateColors )

    return colorings

def isValid( stateColors, graph ):
    """
       isValid : ListOfInt Graph -> Boolean
       Run through the border list to make sure no state's color
       is the same as any of its neighbors.
       Uncolored states are ignored.
       Return True iff there are no clashes.
    """
    for state in range( len( graph.nodes ) ):
        sourceColor = stateColors[ state ]
        if sourceColor != UNCOLORED: # Don't care about uncolored states
            for neighbor in graph.nodes[ state ].neighbors:
                if sourceColor == stateColors[ neighbor ]:
                    return False
    return True

def isComplete( stateColors, graph ):
    """
       isComplete : ListOfInt Graph -> Boolean
       Run through the border list to see if any state has
       not been colored.
       Return True iff all states have been colored.
    """
    for state in range( len( graph.nodes ) ):
        if stateColors[ state ] == UNCOLORED:
            return False
    return True

########## IMPLEMENTATION OF THE BACKTRACKING ALGORITHM ###########

def find_coloring( stateColors, graph, display ):
    """
       find_coloring : ListOfInt Graph fun(ListOfInt) -> ListOfInt | None
       Solve the graph coloring problem using backtracking.
       The problem is expressed as an initial configuration,
       a goal detector, and the means to proceed to other
       configurations.
       Parameters:
        stateColors: the beginning coloring
        borderList: the state adjacency list
        display: a function that displays the map
                 (or None, if no display is desired)
       Return: None if there is no solution, or
               the complete coloring if a solution was found.
       Precondition: isValid(stateColors, graph)
    """
    display( stateColors )
    if isComplete( stateColors, graph ):
        return stateColors
    else:
        nexts = nextColorings( stateColors, graph )
        for nextColoring in nexts:
            # Filter out invalid colorings.
            if isValid( nextColoring, graph ):
                s = find_coloring( nextColoring, graph, display )
                if s != None:
                    return s
            # Here is the backtracking. If the config "nextColoring" did
            # not lead to a solution, backtrack to here and try
            # another one by going to the next iteration of the loop.

        #NOTE: Uncomment this next line if you want to see the map
        #return to fully uncolored if there is no solution.  This makes
        #the program run much slower since it must uncolor and redisplay
        #each state as it unwinds from a pruned path.
        #display( stateColors )

        return None

def displayColoring( window, smap, state_map, nameTable, colorAssignment ):
    """
    displayColoring : GraphWin Map MapModule Graph ListOfInt -> None
    displayColoring draws the smap in the window using states from 
    state_map, names from the nameTable and colors from colorAssignment.
    pre-conditions: length and order of nameTable and colorAssignment match.
    dependencies: COLORS is an array of names of colors to use.
    """
    for stateNum in range( len( colorAssignment ) ):
        state = state_map.getState( \
                       smap, utilities.get( nameTable, stateNum ).name )
        colorNumber = colorAssignment[ stateNum ]
        if colorNumber == UNCOLORED:
            #state.color = "white"
            state.setColor( "white" )
        else:
            #state.color = COLORS[ colorNumber ]
            state.setColor( COLORS[ colorNumber ] )
    state_map.drawMap( smap, window )
    window.flush()
    if SLEEP:
        time.sleep(SLEEP_TIME)
    else:
        input("Hit RETURN to continue...")

########## MAIN PROGRAM ###########

def main():
    """
       main : Void -> None
       Read in some data files and attempt to color a map of a region
       using adjacency information from the files.
       The chosen map can be changed by modifying the COUNTRY constant.
       The desired colors are stored in the COLORS tuple.
    """

    # Set up the graphical map.

    smap = state_map.Map( COUNTRY )
    height2Width = ( smap.max_y - smap.min_y ) / ( smap.max_x - smap.min_x )
    window = graphics.GraphWin( COUNTRY, \
                                WIN_WIDTH, int( WIN_WIDTH * height2Width ) )
    window.setCoords( smap.min_x - MARGIN, smap.max_y + MARGIN, \
                      smap.max_x + MARGIN, smap.min_y - MARGIN )

    # (Advanced) For a partial explanation of "try", see "finally" at the end.
    try:
        # Initialize data structures: adjacency list, state info, blank colors

        graph = buildGraph( COUNTRY )
        states = state_map.getStates( smap )
        stateColors = [ UNCOLORED ] * len( states )

        # Create a simple function that to use to display its progress.
        # (Advanced) We define the function on the fly and pass it to the
        # algorithm hiding the details about how display is accomplished.
        if SHOW_PROGRESS:
            def display( stateColors ):
                displayColoring( window, smap, state_map, graph, stateColors )
        else:
            def display( stateColors):
                pass

        # Find a coloring.

        finalStateColors = find_coloring( stateColors, graph, display )

        # Display the resulting coloring, if there is one.

        if finalStateColors == None:
            print( "No solution." )
        else:
            print( "Here is the solution. ")
            displayColoring( window, smap, state_map, graph, finalStateColors )

        input("Hit return to close.")
    finally:
        # (Advanced) No matter how we arrive here (normally or due to an
        # exception), close the graphics window.
        window.close()

main()

