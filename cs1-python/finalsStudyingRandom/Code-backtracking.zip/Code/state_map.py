# map.py
#
# Original author: unknown
# Redesign: James Heliotis
#           December 2009

# $Revision: 1.2 $

# This file defines a Map class and a State class.
# Each Map is made up of a number of states.
# The purpose of creating these abstractions is to be able to draw
# 2-D maps and visualize state-related data by coloring each state.
#
# Each state is represented as a Polygon, which is essentially
# a sequence of x,y coordinates
#
# The Map class is designed so that it is capable of providing
# a general interface for maps of any country.
#
# Objects from the Zelle graphics library are used to store
# drawing information.

from graphics import *
from random import choice

# Constants ###################################################################

MARGIN = 20

# The State class #############################################################

class State:
    """A state is usually found through its name.
       The following slots are available:
         name -- a str
         abbrev -- a short (2- or 3-character) name abbreviation
         capital -- a tuple containing the name of this state's capital and
                    a graphics.Point containing its location coordinates
         boundary -- a graphics.Polygon object
                     used to draw the state on a Map
         color -- the color to use to draw the state's interior
         neighbors -- a list of State objects that share a border with this one
         drawn -- a boolean stating whether the state has previously been
                  drawn. This is something needed by the graphics package.
    """

    __slots__ = [ "name", "abbrev", "capital", "boundary", "color", \
                  "neighbors", "drawn" ]

    def __init__( self, name, st, cap, capPt, stPoly ):
        """Create a State object.
           Parameters:
             name: state's name as a str
             st: state's abbreviated name as a str
             cap: state's capital city as a str
             capPt: state's capital's location as a graphics.Point
             stPoly: state's boundary as a list of graphics.Polygon objects
        """
        self.name = name
        self.abbrev = st
        self.capital = (cap, capPt)
        self.boundary = stPoly
        self.color = None
        self.neighbors = None
        self.drawn = False

    def setColor( self, color ):
        if self.color != color:
            self.color = color
            self.drawn = False

    def drawState( state, window ):
        """Draw the state's boundary in window (a graphics.Graphwin)
        using the state's stored color.
        """
        # if state.drawn: eraseState( state )
        if not state.drawn:
            state.eraseState()
            state.boundary.setFill(state.color)
            state.boundary.draw(window)
            state.drawn = True

    def eraseState( state ):
        state.boundary.undraw()

# The Map class ###############################################################

class Map:
    """Represents the geometric map of a country.
       Slots:
        name: a str name for this map (see __init__)
        min_x, max_x:
            how wide a window must be to contain all the states in this map
        min_y, max_y:
            how high a window must be to contain all the states in this map
        data: a dictionary with state names as keys and State objects as values
    """

    def __init__( self, name ):
        """Creates a map data structure.
           The str parameter 'name' is used as a prefix to
           a file name used by a Map object to fully initialize
           itself.
        """
        self.name = name
        readMap( self, name + "MapData.txt" )

def getStates( map ):
    "Return a list of all the states in the map."
    return map.data.keys()

def getState( map, state):
    "Return the State object for the given state."
    # !!!! print( "Get State " + state )
    return map.data[state]

def drawMap( map, window ):
    "Draw the map, state by state, on the GraphWin 'window'."
    for state in map.data.values():
        state.drawState( window )

def readMap( map, mapFileName ):
    """Create the dictionary of information on all the states from
       the given file. Every other line in the file starts with a state's
       name followed by information about that state. See code
       below for details.
    """
    # Open and read the entire file into mapFileContents
    # as an array of lines.
    print( "opening " + mapFileName ) # !!!!
    mapFile = open( mapFileName )
    mapFileContents = mapFile.read().rstrip().split('\n')
    mapFile.close()

    map.data = {}
    map.max_x, map.max_y = 0, 0 # Keep track of needed window size.
    map.min_x, map.min_y = 1000000, 1000000
                                # bad practice, but keeps algorithm simple

    # Each state's entry takes up TWO lines.
    for i in range( 0, len(mapFileContents), 2 ):
        # Extract the state, abbreviation, capital, and x,y of capital
        state, abbrev, capital, capX, capY = mapFileContents[ i ].split( ',' )
        capPoint = Point( int( capX ), int( capY ) )

        # Extract polygon coordinates from the next line
        coords = mapFileContents[ i + 1 ].split( ',' )

        # translate them into x,y pairs for point coordinates
        # points is a list of points that make up the state's polygon
        points = []
        for j in range( 0, len( coords ), 2 ):
            x = int( coords[ j ] )
            y = int( coords[ j+1 ] )
            points.append( Point( x, y ) )
            map.max_x = max( x, map.max_x )
            map.max_y = max( y, map.max_y )
            map.min_x = min( x, map.min_x )
            map.min_y = min( y, map.min_y )
            
        statePoly = Polygon( points )

        # Stuff that uses the State class...
        newState = State( state, abbrev, capital, capPoint, statePoly )
        map.data[ state ] = newState
    

# Map demonstration ######################################################

def demo():
    "Demo the US Map."
    colors = ["yellow", "magenta", "lightBlue", "lightGreen"]
    ## us = Map( "../US" )
    us = Map( "./data/US" )
    print( "The map of US has been created." )
    print( "It has", len( getStates( us ) ), "states." )
    win = GraphWin( us.name, 1000, 750 )
    ## win.setCoords( 0, us.height-1, us.width-1, 0 )
    ## make the demo work for the US map
    MARGIN = 50
    win.setCoords( us.min_x - MARGIN, us.max_y + MARGIN, \
                      us.max_x + MARGIN, us.min_y - MARGIN )
    win.setBackground( "white" )
    for state in getStates( us ):
        stateObj = getState( us, state )
        # stateObj.color = choice( colors )
        stateObj.setColor( choice( colors ) )
        stateObj.drawState( win )
    win.flush()
    input( "Hit ENTER." )
    print( "Good Bye!" )
    
if __name__ == '__main__':
    demo()
