"""
  Some handy functions
  Author: James Heliotis
  $Revision: 1.2 $
"""

class GraphNode( object ):
    """
       A node in a graph consists of its name and a list of NUMBERS 
       representing the positions of this node's neighbors
       in some list of GraphNodes (See Graph below).
    """
    __slots__ = ( "name", "neighbors" )

    def __init__( self, nodeName ):
        self.name = nodeName
        self.neighbors = []

    def __str__( self ):
        return "STATE:" + self.name + ": " + str( self.neighbors )


class Graph( object ):
    """
       Graph stores a list of correspondences between node names
       and numbers.
    """

    __slots__ = ( "nodes" )

    def __init__( self ):
        "Create an empty list of correspondences."
        self.nodes = []


def add( graph, nodeName ):
    """
       add : Graph String -> Natural
       Add a new node to the graph. If a node by the given nodeName is
       already in the graph, the graph is not changed.
       The index of the node in the graph is returned.
    """
    location = locate( graph, nodeName )
    if location == None:
        node = GraphNode( nodeName )
        location = len( graph.nodes )
        graph.nodes.append( node )
    return location

def locate( graph, nodeName ):
    """
       locate : Graph String -> Natural | None
       Find nodeName in the graph.
       Return its number (index), or None if not found.
    """
    for index in range( len( graph.nodes ) ):
        if nodeName == graph.nodes[ index ].name:
            return index
    return None

def get( graph, index ):
    """
       get : Graph Natural -> GraphNode
       Return the node at position index in the graph.
    """
    return graph.nodes[ index ]

