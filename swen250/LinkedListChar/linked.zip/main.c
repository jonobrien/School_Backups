
#include <stdio.h>
#include <stdlib.h>
#include "linked.h"
	
struct node* head = NULL;

void main() {
	int value;
	struct node* head = NULL;
	
	push( 2 );
	push(3);
	push(5);
	value = pop();
	printf("Length of list = %d\n", length());
	printList();
	appendNode(8);
	printList();
	
	// add additional tests here....
	
}
