/*****************************************************************************
* EECC-381 Homework Data Generator
*   Returns 1 when X and Y have been returned with valid data and returns 0
*   when no more data is available.
*****************************************************************************/
int DataPoints(double *X, double *Y);

