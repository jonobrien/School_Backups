In order to make use of the makefile, simply run the "make" command in the 
hw3/ directory. This will take the two targets of TestList and TestSearch, and 
compile both of these executables after compiling andy files they depend on

Usage: 
$ make
$ ./TestList american-english-words
$ ./TestSearch american-english-words search.txt

Please feel free to create a text file other than search and 
include in cmdline args, or simply edit contents of search.txt
